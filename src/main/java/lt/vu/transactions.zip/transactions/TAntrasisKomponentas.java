package lt.vu.transactions;

import jakarta.annotation.Resource;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Named;
import jakarta.transaction.TransactionSynchronizationRegistry;

import javax.transaction.Transactional;

@Named
@RequestScoped
public class TAntrasisKomponentas {

    @Resource
    private TransactionSynchronizationRegistry tx;

    @Transactional
    public void vykdytiTransakcija() {
        System.out.println("Antrasis komponentas, transakcijos ID: " + tx.getTransactionKey());
    }
}
