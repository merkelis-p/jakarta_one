# Java EE practice project
Project is based on *Maven*, thus import project to IntelliJ IDEA by:
* File -> Open... -> pick `pom.xml` file.

## Application Server configuration

### WildFly

1. Download ZIP of WildFly 26 "Jakarta EE 8 Full & Web Distribution" from: http://wildfly.org/downloads/
2. Unzip
3. In IntelliJ IDEA: register "JBoss Server" -> local:
    * Press "Fix", choose "exploded war"
4. Run the server, project should start successfully.
