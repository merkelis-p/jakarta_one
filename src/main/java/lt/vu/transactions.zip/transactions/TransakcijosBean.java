package lt.vu.transactions;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;

@Named
@RequestScoped
public class TransakcijosBean {

    @Inject
    private TPirmasisKomponentas komponentas1;


    public void vykdytiTransakcija() {
        komponentas1.vykdytiTransakcija();
    }
}
