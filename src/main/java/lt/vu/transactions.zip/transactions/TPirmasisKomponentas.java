package lt.vu.transactions;

import jakarta.annotation.Resource;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import javax.transaction.Transactional;

import jakarta.inject.Named;
import jakarta.transaction.TransactionSynchronizationRegistry;

@Named
@RequestScoped
public class TPirmasisKomponentas {

    @Inject
    private TAntrasisKomponentas antrasis;

    @Resource
    private TransactionSynchronizationRegistry tx;

    @Transactional
    public void vykdytiTransakcija() {
        System.out.println("Pirmasis komponentas, transakcijos ID: " + tx.getTransactionKey());
        antrasis.vykdytiTransakcija();
    }
}

